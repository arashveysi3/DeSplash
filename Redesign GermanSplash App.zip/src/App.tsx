import { useEffect, useState } from "react"

type IconName = "home" | "cards" | "quiz" | "exam" | "flame" | "search" | "weak" | "board" | "user" | "more" | "bolt" | "arrow" | "book" | "sound" | "check" | "close" | "settings" | "offline" | "chevron"

function Icon({ name, size = 20 }: { name: IconName size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: (
      <>
        <path d="m3 10 9-7 9 7" />
        <path d="M5 9v11h14V9" />
        <path d="M9 20v-6h6v6" />
      </>
    ),
    cards: (
      <>
        <rect x="4" y="3" width="14" height="17" rx="3" />
        <path d="m9 8 4-2v12" />
        <path d="M8 18h8" />
      </>
    ),
    quiz: (
      <>
        <path d="M9.5 3.5a6.5 6.5 0 1 1-4.6 11.1L3 16l.7-3A6.5 6.5 0 0 1 9.5 3.5Z" />
        <path d="M8 8a2 2 0 1 1 2.2 2c-.7.2-.7.8-.7 1.3" />
        <path d="M9.5 14h.01" />
        <path d="M15 16h6v4h-6z" />
      </>
    ),
    exam: (
      <>
        <path d="M6 3h12v18H6z" />
        <path d="M9 7h6M9 11h6M9 15h3" />
      </>
    ),
    flame: (
      <path d="M12 22c4.4 0 7-3.1 7-7.2 0-3.5-2.2-6.7-5-9.8.2 3-1.5 4.3-2.5 2C10.7 5.3 9.2 3.2 7 2c.2 4.3-2 6.3-2 10.7C5 17.7 7.9 22 12 22Z" />
    ),
    search: (
      <>
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="m16 16 5 5" />
      </>
    ),
    weak: (
      <>
        <path d="M12 3 2.8 20h18.4L12 3Z" />
        <path d="M12 9v5M12 17h.01" />
      </>
    ),
    board: (
      <>
        <path d="M6 21v-7h4v7M14 21V9h4v12M10 21V3h4v18" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21c.7-4 3.4-6 8-6s7.3 2 8 6" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
      </>
    ),
    bolt: <path d="m13 2-8 12h7l-1 8 8-12h-7l1-8Z" />,
    arrow: (
      <>
        <path d="M5 12h14M14 7l5 5-5 5" />
      </>
    ),
    book: (
      <>
        <path d="M4 4.5A3.5 3.5 0 0 1 7.5 1H12v18H7.5A3.5 3.5 0 0 0 4 22.5Z" />
        <path d="M20 4.5A3.5 3.5 0 0 0 16.5 1H12v18h4.5a3.5 3.5 0 0 1 3.5 3.5Z" />
      </>
    ),
    sound: (
      <>
        <path d="M11 5 6 9H3v6h3l5 4Z" />
        <path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.8 1.8 0 0 0 .4 2l.1.1-2.8 2.8-.1-.1a1.8 1.8 0 0 0-2-.4 1.8 1.8 0 0 0-1 1.6v.2h-4V21a1.8 1.8 0 0 0-1-1.6 1.8 1.8 0 0 0-2 .4l-.1.1-2.8-2.8.1-.1a1.8 1.8 0 0 0 .4-2A1.8 1.8 0 0 0 3 14H2.8v-4H3a1.8 1.8 0 0 0 1.6-1 1.8 1.8 0 0 0-.4-2l-.1-.1 2.8-2.8.1.1a1.8 1.8 0 0 0 2 .4A1.8 1.8 0 0 0 10 3V2.8h4V3a1.8 1.8 0 0 0 1 1.6 1.8 1.8 0 0 0 2-.4l.1-.1 2.8 2.8-.1.1a1.8 1.8 0 0 0-.4 2 1.8 1.8 0 0 0 1.6 1h.2v4H21a1.8 1.8 0 0 0-1.6 1Z" />
      </>
    ),
    offline: (
      <>
        <path d="M5 13a10 10 0 0 1 14 0M8.5 16.5a5 5 0 0 1 7 0M12 20h.01" />
        <path d="M3 3l18 18" />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

const nav = [
  { id: "home", label: "Heute", icon: "home" as IconName },
  { id: "study", label: "Lernen", icon: "cards" as IconName },
  { id: "quiz", label: "Quiz", icon: "quiz" as IconName },
  { id: "exam", label: "Prüfung", icon: "exam" as IconName },
]

const tools = [
  { id: "streak", label: "Streak", note: "12 Tage", icon: "flame" as IconName },
  {
    id: "search",
    label: "Suche",
    note: "2.318 Wörter",
    icon: "search" as IconName,
  },
  { id: "weak", label: "Fehlerbank", note: "18", icon: "weak" as IconName },
  { id: "board", label: "Rangliste", note: "#8", icon: "board" as IconName },
]

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="brand">
      <div className="brand-mark">
        <span>D</span>
      </div>
      {!compact && (
        <div>
          <strong>
            German<span>Splash</span>
          </strong>
          <small>DEUTSCH, DAS BLEIBT.</small>
        </div>
      )}
    </div>
  )
}

function Progress({
  value,
  tone = "red",
}: {
  value: number
  tone?: "red" | "yellow" | "blue" | "green"
}) {
  return (
    <div className={`progress ${tone}`}>
      <span style={{ width: `${value}%` }} />
    </div>
  )
}

function AppButton({
  children,
  kind = "dark",
  onClick,
  icon,
}: {
  children: React.ReactNode
  kind?: "dark" | "light" | "ghost" | "yellow"
  onClick?: () => void
  icon?: IconName
}) {
  return (
    <button className={`btn ${kind}`} onClick={onClick}>
      {children}
      {icon && <Icon name={icon} size={18} />}
    </button>
  )
}

function Splash({ onDone }: { onDone: () => void }) {
  return (
    <div className="splash">
      <div className="splash-top">
        <Brand />
      </div>
      <div className="splash-art" aria-hidden="true">
        <div className="orbit orbit-one" />
        <div className="orbit orbit-two" />
        <div className="letter-card card-a">
          A<small>APFEL</small>
        </div>
        <div className="letter-card card-umlaut">
          Ä<small>ÄPFEL</small>
        </div>
        <div className="spark spark-one" />
        <div className="spark spark-two" />
      </div>
      <div className="splash-copy">
        <span className="eyebrow">DEIN DEUTSCH-MOMENT BEGINNT</span>
        <h1>
          Wörter, die
          <br />
          <em>bleiben.</em>
        </h1>
        <p>
          German vocabulary. Persian warmth.
          <br />A little progress, every day.
        </p>
        <AppButton kind="dark" icon="arrow" onClick={onDone}>
          Los geht’s
        </AppButton>
        <small className="safe-note">
          <Icon name="offline" size={15} /> 2.318 Wörter · offline bereit
        </small>
      </div>
    </div>
  )
}

function ScopePill() {
  return (
    <button className="scope-pill">
      <span>A1.1</span>
      <b>Lektion 7–9</b>
      <small>124 Wörter</small>
      <Icon name="chevron" size={16} />
    </button>
  )
}

function Home({ go }: { go: (id: string) => void }) {
  return (
    <div className="page home-page">
      <section className="welcome">
        <div>
          <span className="eyebrow">GUTEN MORGEN, SARA</span>
          <h1>
            Dein Deutsch
            <br />
            wartet auf dich.
          </h1>
        </div>
        <div className="today-ring">
          <svg viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="43" />
            <circle className="filled" cx="50" cy="50" r="43" />
          </svg>
          <div>
            <Icon name="flame" size={24} />
            <b>12</b>
            <small>TAGE</small>
          </div>
        </div>
      </section>

      <section className="daily-card">
        <div className="daily-main">
          <div className="daily-icon">
            <Icon name="cards" size={25} />
            <span>10</span>
          </div>
          <div>
            <span className="eyebrow">HEUTE · 8 MIN</span>
            <h2>Daily Pack</h2>
            <p>10 fällige Wörter aus deinem aktuellen Lernbereich.</p>
          </div>
        </div>
        <div className="daily-progress">
          <div>
            <span>Tagesziel</span>
            <b>0 / 10 Wörter</b>
          </div>
          <Progress value={8} tone="yellow" />
        </div>
        <AppButton kind="yellow" icon="arrow" onClick={() => go("study")}>
          Pack starten
        </AppButton>
      </section>

      <section className="momentum">
        <div className="section-heading">
          <div>
            <span className="eyebrow">DEIN MOMENTUM</span>
            <h2>Stark unterwegs.</h2>
          </div>
          <button className="text-link" onClick={() => go("streak")}>
            Details <Icon name="arrow" size={16} />
          </button>
        </div>
        <div className="stat-grid">
          <div className="stat-card">
            <div className="stat-icon fire">
              <Icon name="flame" />
            </div>
            <b>12</b>
            <span>Tagesserie</span>
            <small>Bestwert: 21</small>
          </div>
          <div className="stat-card">
            <div className="stat-icon bolt">
              <Icon name="bolt" />
            </div>
            <b>2.840</b>
            <span>Gesamt-XP</span>
            <small>+180 diese Woche</small>
          </div>
          <div className="stat-card mastery">
            <div className="stat-icon book">
              <Icon name="book" />
            </div>
            <b>68%</b>
            <span>A1.1 gemeistert</span>
            <Progress value={68} tone="blue" />
          </div>
        </div>
      </section>

      <section className="continue-section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">WEITERMACHEN</span>
            <h2>Was möchtest du tun?</h2>
          </div>
        </div>
        <div className="activity-grid">
          <button
            className="activity-card quiz-card"
            onClick={() => go("quiz")}
          >
            <span className="activity-kicker">EMPFOHLEN · +100 XP</span>
            <div className="activity-symbol">
              <Icon name="quiz" size={28} />
            </div>
            <h3>4-Choice Sprint</h3>
            <p>Der schnellste Weg, Wörter zu festigen.</p>
            <span className="activity-action">
              Quiz starten <Icon name="arrow" size={18} />
            </span>
          </button>
          <button
            className="activity-card exam-card"
            onClick={() => go("exam")}
          >
            <span className="activity-kicker">PRÜFUNGSMODUS</span>
            <div className="activity-symbol">
              <Icon name="exam" size={28} />
            </div>
            <h3>A1 Probeprüfung</h3>
            <p>Ruhig, realistisch und ohne Zeitdruck.</p>
            <span className="activity-action">
              Vorbereiten <Icon name="arrow" size={18} />
            </span>
          </button>
        </div>
      </section>

      <section className="scope-card">
        <div>
          <span className="eyebrow">AKTUELLER LERNBEREICH</span>
          <h3>Menschen A1.1 · Lektion 7–9</h3>
          <p>124 Wörter · 18 fällig · 6 schwach</p>
        </div>
        <button>
          Ändern <Icon name="chevron" size={16} />
        </button>
      </section>
    </div>
  )
}

function Study() {
  const [step, setStep] = useState<"ready" | "card" | "summary">("ready")
  const [flipped, setFlipped] = useState(false)
  const [index, setIndex] = useState(0)
  const words = [
    {
      article: "der",
      word: "Augenblick",
      plural: "Augenblicke",
      en: "moment",
      fa: "لحظه",
      example: "Warte bitte einen Augenblick.",
    },
    {
      article: "die",
      word: "Erfahrung",
      plural: "Erfahrungen",
      en: "experience",
      fa: "تجربه",
      example: "Das war eine gute Erfahrung.",
    },
    {
      article: "das",
      word: "Ergebnis",
      plural: "Ergebnisse",
      en: "result",
      fa: "نتیجه",
      example: "Das Ergebnis ist sehr gut.",
    },
  ]
  const current = words[index % words.length]
  const rate = () => {
    if (index >= 2) setStep("summary")
    else {
      setIndex(index + 1)
      setFlipped(false)
    }
  }
  return (
    <div className="page study-page">
      <div className="page-title-row">
        <div>
          <span className="eyebrow">SPACED REPETITION</span>
          <h1>Lernen</h1>
        </div>
        <ScopePill />
      </div>
      {step === "ready" && (
        <div className="study-ready">
          <div className="pack-visual">
            <div className="mini-card m1">der</div>
            <div className="mini-card m2">die</div>
            <div className="mini-card m3">das</div>
            <span>10</span>
          </div>
          <span className="eyebrow">DEIN NÄCHSTES PACK</span>
          <h2>Bereit für 10 Wörter?</h2>
          <p>
            Ein kurzer Durchgang dauert etwa 8 Minuten. Du kannst jederzeit
            pausieren.
          </p>
          <div className="pack-options">
            <button className="selected">
              10<small>sanft</small>
            </button>
            <button>
              20<small>fokussiert</small>
            </button>
            <button>
              50<small>intensiv</small>
            </button>
          </div>
          <AppButton kind="dark" icon="arrow" onClick={() => setStep("card")}>
            Pack starten
          </AppButton>
          <div className="gender-legend">
            <span className="der">der</span>
            <span className="die">die</span>
            <span className="das">das</span>
          </div>
        </div>
      )}
      {step === "card" && (
        <div className="study-active">
          <div className="pack-status">
            <button onClick={() => setStep("ready")}>
              <Icon name="close" />
            </button>
            <div>
              <span>PACK {index + 1} / 10</span>
              <Progress value={(index + 1) * 10} tone="yellow" />
            </div>
            <b>+{index * 3} XP</b>
          </div>
          <button
            className={`flashcard ${
              flipped ? "flipped" : ""
            } gender-${current.article}`}
            onClick={() => setFlipped(!flipped)}
          >
            {!flipped ? (
              <div className="card-face front">
                <div className="card-meta">
                  <span>A1.1 · L8</span>
                  <span>{current.article}</span>
                </div>
                <div className="word-wrap">
                  <span className="article">{current.article}</span>
                  <strong>{current.word}</strong>
                  <small>die {current.plural}</small>
                </div>
                <div className="tap-hint">
                  Tippen zum Umdrehen <span>↻</span>
                </div>
              </div>
            ) : (
              <div className="card-face back">
                <div className="translation">
                  <small>ENGLISH</small>
                  <strong>{current.en}</strong>
                </div>
                <div className="translation fa" dir="rtl">
                  <small>فارسی</small>
                  <strong>{current.fa}</strong>
                </div>
                <div className="example">
                  <small>BEISPIEL</small>
                  <p>{current.example}</p>
                  <button onClick={(e) => e.stopPropagation()}>
                    <Icon name="sound" size={18} />
                  </button>
                </div>
                <span className="tap-hint">
                  Tippen für Vorderseite <span>↻</span>
                </span>
              </div>
            )}
          </button>
          <div className="listen-row">
            <button>
              <Icon name="sound" /> Anhören
            </button>
            <button>Mikrofon · Aussprache</button>
          </div>
          {flipped ? (
            <div className="rating-row">
              <button onClick={rate}>
                <span>Again</span>
                <b>+1</b>
              </button>
              <button onClick={rate}>
                <span>Hard</span>
                <b>+2</b>
              </button>
              <button onClick={rate}>
                <span>Good</span>
                <b>+3</b>
              </button>
              <button onClick={rate}>
                <span>Easy</span>
                <b>+5</b>
              </button>
            </div>
          ) : (
            <p className="swipe-hint">
              ← Noch mal &nbsp;&nbsp; Wischen oder tippen &nbsp;&nbsp; Gewusst →
            </p>
          )}
        </div>
      )}
      {step === "summary" && (
        <div className="summary-card">
          <div className="success-mark">
            <Icon name="check" size={36} />
          </div>
          <span className="eyebrow">PACK GESCHAFFT</span>
          <h2>Stark gemacht, Sara.</h2>
          <p>Diese zehn Wörter sitzen schon ein bisschen besser.</p>
          <div className="score-circle">
            <strong>
              8<small>/10</small>
            </strong>
            <span>RICHTIG</span>
          </div>
          <div className="summary-stats">
            <div>
              <Icon name="bolt" />
              <b>+34</b>
              <span>XP verdient</span>
            </div>
            <div>
              <Icon name="flame" />
              <b>12</b>
              <span>Streak aktiv</span>
            </div>
          </div>
          <div className="word-pills">
            <span>Augenblick ✓</span>
            <span>Erfahrung ✓</span>
            <span className="miss">Ergebnis · wiederholen</span>
          </div>
          <AppButton
            kind="dark"
            icon="arrow"
            onClick={() => {
              setStep("ready")
              setIndex(0)
            }}
          >
            Speichern & weiter
          </AppButton>
          <button className="text-link">Pack verwerfen</button>
        </div>
      )}
    </div>
  )
}

function Quiz() {
  const [stage, setStage] = useState<"setup" | "question" | "report">("setup")
  const [answer, setAnswer] = useState<number | null>(null)
  const [q, setQ] = useState(1)
  const choose = (i: number) => {
    setAnswer(i)
    window.setTimeout(() => {
      if (q >= 3) setStage("report")
      else {
        setQ(q + 1)
        setAnswer(null)
      }
    }, 700)
  }
  if (stage === "question")
    return (
      <div className="page quiz-play">
        <div className="quiz-top">
          <button onClick={() => setStage("setup")}>
            <Icon name="close" />
          </button>
          <div>
            <span>4-CHOICE · {q} VON 10</span>
            <Progress value={q * 10} tone="yellow" />
          </div>
          <b>
            <Icon name="bolt" size={16} /> {q * 10}
          </b>
        </div>
        <div className="question-wrap">
          <span className="eyebrow">WÄHLE DIE RICHTIGE BEDEUTUNG</span>
          <h1>
            {q === 2
              ? "die Erfahrung"
              : q === 3
                ? "zuverlässig"
                : "der Augenblick"}
          </h1>
          <button className="speak-button">
            <Icon name="sound" /> Anhören
          </button>
        </div>
        <div className="answer-grid">
          {[
            "moment · لحظه",
            "view · منظره",
            "intention · قصد",
            "opportunity · فرصت",
          ].map((item, i) => (
            <button
              key={item}
              className={
                answer === null
                  ? ""
                  : i === 0
                    ? "correct"
                    : answer === i
                      ? "wrong"
                      : "dim"
              }
              onClick={() => choose(i)}
              disabled={answer !== null}
            >
              <span>{String.fromCharCode(65 + i)}</span>
              <b>{item}</b>
              {answer !== null && i === 0 && <Icon name="check" />}
            </button>
          ))}
        </div>
        <p className="keyboard-hint">Du kannst auch A, B, C oder D drücken.</p>
      </div>
    )
  if (stage === "report")
    return (
      <div className="page report-page">
        <div className="report-hero">
          <div className="success-mark">
            <Icon name="check" size={36} />
          </div>
          <span className="eyebrow">QUIZ ABGESCHLOSSEN</span>
          <h1>Sehr stark.</h1>
          <p>Dein Wortschatz wird sicherer.</p>
          <div className="accuracy">
            <strong>90%</strong>
            <span>GENAUIGKEIT</span>
          </div>
        </div>
        <div className="report-stats">
          <div>
            <span>RICHTIG</span>
            <b>9</b>
            <small>von 10</small>
          </div>
          <div>
            <span>XP</span>
            <b>+96</b>
            <small>verdient</small>
          </div>
          <div>
            <span>STREAK</span>
            <b>12</b>
            <small>Tage</small>
          </div>
        </div>
        <div className="insight-card">
          <div className="insight-icon">
            <Icon name="bolt" />
          </div>
          <div>
            <span className="eyebrow">DEIN FOKUS</span>
            <h3>Lektion 8 sitzt fast.</h3>
            <p>
              Nur <b>die Erfahrung</b> braucht noch eine Runde. Wir haben sie
              deiner Fehlerbank hinzugefügt.
            </p>
          </div>
        </div>
        <div className="next-actions">
          <AppButton kind="dark" icon="arrow" onClick={() => setStage("setup")}>
            Schwache Wörter üben
          </AppButton>
          <AppButton kind="light" onClick={() => setStage("setup")}>
            Neues Quiz
          </AppButton>
        </div>
      </div>
    )
  return (
    <div className="page quiz-page">
      <div className="page-title-row">
        <div>
          <span className="eyebrow">TRAINING</span>
          <h1>Quiz</h1>
          <p>Kurze Challenges. Sofortiges Feedback.</p>
        </div>
        <ScopePill />
      </div>
      <section className="featured-mode">
        <span className="mode-badge">BESTE XP-RATE</span>
        <div className="mode-art">
          <div>A</div>
          <div>B</div>
          <div>C</div>
        </div>
        <div className="mode-copy">
          <span className="eyebrow">EMPFOHLEN</span>
          <h2>4-Choice Sprint</h2>
          <p>Finde die richtige Bedeutung. Schnell, fokussiert, effektiv.</p>
          <div className="mode-meta">
            <span>10 Fragen</span>
            <span>~4 Min</span>
            <span>bis +100 XP</span>
          </div>
          <AppButton
            kind="yellow"
            icon="arrow"
            onClick={() => setStage("question")}
          >
            Starten
          </AppButton>
        </div>
      </section>
      <div className="section-heading">
        <div>
          <span className="eyebrow">TRAININGSMODI</span>
          <h2>Wähle deine Challenge</h2>
        </div>
      </div>
      <div className="mode-grid">
        {[
          ["Diktat", "Hören & exakt tippen", "+12 XP", "sound"],
          ["Artikel", "der, die oder das?", "+8 XP", "cards"],
          ["DE → فارسی", "Auf Persisch antworten", "+12 XP", "arrow"],
          ["Diktat-Check", "Falsche Schreibweise finden", "+10 XP", "search"],
        ].map(([title, desc, xp, icon]) => (
          <button
            className="mode-card"
            key={title}
            onClick={() => setStage("question")}
          >
            <div className="mode-icon">
              <Icon name={icon as IconName} />
            </div>
            <div>
              <h3>{title}</h3>
              <p>{desc}</p>
            </div>
            <span>{xp}</span>
            <Icon name="chevron" size={18} />
          </button>
        ))}
      </div>
      <section className="games-strip">
        <div>
          <span className="eyebrow">SPIELHALLE</span>
          <h2>Mehr Tempo. Mehr XP.</h2>
          <p>Match Dash · Blitzsprint · SatzBau · WortSturm</p>
        </div>
        <AppButton kind="light" icon="arrow">
          Spiele entdecken
        </AppButton>
      </section>
    </div>
  )
}

function Exam() {
  return (
    <div className="page exam-page">
      <div className="page-title-row">
        <div>
          <span className="eyebrow">PRÜFUNGSVORBEREITUNG</span>
          <h1>Probeprüfung</h1>
          <p>Realistisch üben. Ruhig abliefern.</p>
        </div>
        <div className="book-toggle">
          <button className="active">A1.1</button>
          <button>A1.2</button>
        </div>
      </div>
      <section className="exam-hero">
        <div className="exam-copy">
          <span className="eyebrow">MENSCHEN A1.1 · FINAL MOCK</span>
          <h2>
            Bereit zu sehen,
            <br />
            wo du stehst?
          </h2>
          <p>
            55 Fragen in vier Teilen. Ohne Zeitdruck, mit ausführlicher
            Auswertung.
          </p>
          <AppButton kind="yellow" icon="arrow">
            Prüfung starten
          </AppButton>
        </div>
        <div className="best-score">
          <span>BESTLEISTUNG</span>
          <strong>
            82<small>%</small>
          </strong>
          <p>45 von 55</p>
          <small>zuletzt vor 6 Tagen</small>
        </div>
      </section>
      <div className="exam-parts">
        {[
          ["01", "Diktation", "15 Fragen", "Rechtschreibung"],
          ["02", "Grammatik", "15 Fragen", "Strukturen"],
          ["03", "Wortschatz", "15 Fragen", "Bedeutung"],
          ["04", "Lesen", "10 Fragen", "Verständnis"],
        ].map(([n, title, count, note]) => (
          <div key={n}>
            <span>{n}</span>
            <div>
              <h3>{title}</h3>
              <p>{note}</p>
            </div>
            <b>{count}</b>
          </div>
        ))}
      </div>
      <section className="practice-parts">
        <div>
          <span className="eyebrow">EINZELTEILE ÜBEN</span>
          <h2>Noch nicht bereit für alles?</h2>
          <p>
            Trainiere gezielt einen Abschnitt. Jede Runde wird neu gemischt.
          </p>
        </div>
        <button>
          Teil auswählen <Icon name="chevron" />
        </button>
      </section>
      <div className="honest-note">
        <Icon name="sound" />
        <div>
          <b>Hören ist noch nicht dabei.</b>
          <p>
            Dieser Mock deckt Diktation, Grammatik, Wortschatz und Lesen ab.
            Dein Fortschritt bleibt natürlich sicher.
          </p>
        </div>
      </div>
    </div>
  )
}

function Streak() {
  const days = Array.from({ length: 35 }, (_, i) => i - 3)
  return (
    <div className="page streak-page">
      <section className="streak-hero">
        <div className="tier-orb">
          <Icon name="flame" size={40} />
        </div>
        <span className="eyebrow">INFERNO · STUFE 2</span>
        <h1>
          12 <small>TAGE</small>
        </h1>
        <p dir="rtl">۱۲ روز پیوسته — عالیه، ادامه بده</p>
        <div className="tier-progress">
          <div>
            <span>Nächste Stufe: Thunderstorm</span>
            <b>12 / 30</b>
          </div>
          <Progress value={40} tone="yellow" />
        </div>
      </section>
      <div className="streak-stats">
        <div>
          <span>AKTUELL</span>
          <b>12</b>
          <small>Tage</small>
        </div>
        <div>
          <span>BESTWERT</span>
          <b>21</b>
          <small>Tage</small>
        </div>
        <div>
          <span>GESAMT</span>
          <b>48</b>
          <small>aktive Tage</small>
        </div>
        <div className="freeze">
          <span>FREESTREAK</span>
          <b>2</b>
          <small>verfügbar</small>
        </div>
      </div>
      <section className="calendar-card">
        <div className="calendar-head">
          <button>‹</button>
          <div>
            <h2>März 2026</h2>
            <p dir="rtl">اسفند ۱۴۰۴</p>
          </div>
          <button>›</button>
        </div>
        <div className="weekdays" dir="rtl">
          {["ش", "ی", "د", "س", "چ", "پ", "ج"].map((d, i) => (
            <span key={i}>{d}</span>
          ))}
        </div>
        <div className="calendar-grid">
          {days.map((d, i) => (
            <button
              key={i}
              className={
                d < 1 || d > 31
                  ? "outside"
                  : d < 15
                    ? d === 10
                      ? "frozen"
                      : "done"
                    : d === 15
                      ? "today"
                      : ""
              }
            >
              {d > 0 && d < 32 ? d : ""}
              {d === 10 && <small>❄</small>}
              {d > 0 && d < 15 && d !== 10 && <i />}
            </button>
          ))}
        </div>
        <div className="calendar-legend">
          <span>
            <i className="complete" />
            Geschafft
          </span>
          <span>
            <i className="ice" />
            Freeze
          </span>
          <span>
            <i className="missed" />
            Ruhetag
          </span>
        </div>
      </section>
      <section className="tier-list">
        <div className="section-heading">
          <div>
            <span className="eyebrow">DEINE EVOLUTION</span>
            <h2>Beständigkeit wird sichtbar.</h2>
          </div>
        </div>
        <div className="tier-track">
          <div className="tier done">
            <b>01</b>
            <span>
              Ember<small>1–9 Tage</small>
            </span>
            <Icon name="check" />
          </div>
          <div className="tier active">
            <b>02</b>
            <span>
              Inferno<small>10–29 Tage</small>
            </span>
            <Icon name="flame" />
          </div>
          <div className="tier">
            <b>03</b>
            <span>
              Thunderstorm<small>30–59 Tage</small>
            </span>
            <i>🔒</i>
          </div>
          <div className="tier">
            <b>04</b>
            <span>
              Tsunami<small>60–89 Tage</small>
            </span>
            <i>🔒</i>
          </div>
        </div>
      </section>
    </div>
  )
}

function More({ go }: { go: (id: string) => void }) {
  return (
    <div className="page more-page">
      <div className="page-title-row">
        <div>
          <span className="eyebrow">DEIN BEREICH</span>
          <h1>Mehr</h1>
          <p>Werkzeuge, Fortschritt und Einstellungen.</p>
        </div>
      </div>
      <section className="profile-banner">
        <div className="avatar">SA</div>
        <div>
          <h2>Sara Ahmadi</h2>
          <p>sara.a · A1 Lernerin</p>
        </div>
        <span>PRO</span>
        <Icon name="chevron" />
      </section>
      <div className="more-grid">
        {tools.map((item) => (
          <button key={item.id} onClick={() => go(item.id)}>
            <div className={`more-icon ${item.id}`}>
              <Icon name={item.icon} />
            </div>
            <div>
              <h3>{item.label}</h3>
              <p>{item.note}</p>
            </div>
            <Icon name="chevron" />
          </button>
        ))}
        <button>
          <div className="more-icon books">
            <Icon name="book" />
          </div>
          <div>
            <h3>Bücher & Lektionen</h3>
            <p>3 Bücher · 2.318 Wörter</p>
          </div>
          <Icon name="chevron" />
        </button>
        <button>
          <div className="more-icon settings">
            <Icon name="settings" />
          </div>
          <div>
            <h3>Einstellungen</h3>
            <p>Ton, Updates, Sprache</p>
          </div>
          <Icon name="chevron" />
        </button>
      </div>
      <div className="offline-card">
        <Icon name="offline" />
        <div>
          <b>Offline bereit</b>
          <p>Alle Wörter sind auf diesem Gerät. Dein Fortschritt ist sicher.</p>
        </div>
        <span>AKTUELL</span>
      </div>
    </div>
  )
}

function Placeholder({ id, go }: { id: string go: (id: string) => void }) {
  const data: Record<string, [string, string, string, IconName]> = {
    search: [
      "Suche",
      "Suche Deutsch, English, فارسی oder Lektion …",
      "2.318 Wörter sind offline durchsuchbar.",
      "search",
    ],
    weak: [
      "Fehlerbank",
      "18 Wörter warten auf dich.",
      "Fehler sind keine Niederlagen. Sie zeigen dir nur, was als Nächstes dran ist.",
      "weak",
    ],
    board: [
      "Rangliste",
      "Du bist diese Woche #8.",
      "Noch 420 XP bis zu den Top 5. Lern ehrlich, steig stetig.",
      "board",
    ],
  }
  const [title, headline, body, icon] = data[id] || data.search
  return (
    <div className="page placeholder-page">
      <button className="back-link" onClick={() => go("more")}>
        ← Mehr
      </button>
      <div className={`placeholder-icon ${id}`}>
        <Icon name={icon} size={34} />
      </div>
      <span className="eyebrow">{title.toUpperCase()}</span>
      <h1>{headline}</h1>
      <p>{body}</p>
      {id === "search" && (
        <div className="search-box">
          <Icon name="search" />
          <input placeholder="z. B. Augenblick, moment, لحظه" />
          <kbd>⌘ K</kbd>
        </div>
      )}
      {id === "weak" && (
        <>
          <AppButton kind="dark" icon="arrow" onClick={() => go("study")}>
            18 Wörter üben
          </AppButton>
          <div className="weak-list">
            {["die Erfahrung", "zuverlässig", "der Unterschied"].map((w, i) => (
              <div key={w}>
                <span className={i === 0 ? "die" : i === 1 ? "das" : "der"}>
                  {i === 0 ? "die" : i === 1 ? "" : "der"}
                </span>
                <b>{w}</b>
                <small>
                  {i === 0
                    ? "experience · تجربه"
                    : i === 1
                      ? "reliable · قابل اعتماد"
                      : "difference · تفاوت"}
                </small>
                <Icon name="sound" />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

export default function App() {
  const [splash, setSplash] = useState(true)
  const [active, setActive] = useState("home")
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [active])
  const go = (id: string) => setActive(id)
  if (splash) return <Splash onDone={() => setSplash(false)} />
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Brand />
        <nav>
          <span className="nav-label">LERNEN</span>
          {nav.map((item) => (
            <button
              key={item.id}
              className={active === item.id ? "active" : ""}
              onClick={() => go(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
              {item.id === "study" && <small>18</small>}
            </button>
          ))}
          <span className="nav-label second">WERKZEUGE</span>
          {tools.map((item) => (
            <button
              key={item.id}
              className={active === item.id ? "active" : ""}
              onClick={() => go(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
              <small>{item.note}</small>
            </button>
          ))}
        </nav>
        <div className="sidebar-account">
          <div className="avatar">SA</div>
          <div>
            <b>Sara</b>
            <span>Level A1 · PRO</span>
          </div>
          <Icon name="more" />
        </div>
      </aside>
      <header className="mobile-header">
        <Brand compact />
        <ScopePill />
        <button className="xp-chip">
          <Icon name="bolt" size={16} />
          2.840
        </button>
        <button className="avatar">SA</button>
      </header>
      <main>
        <div className="desktop-topbar">
          <ScopePill />
          <div className="top-actions">
            <span>
              <i /> Offline bereit
            </span>
            <button>
              <Icon name="search" />
            </button>
            <button>
              <Icon name="settings" />
            </button>
            <div className="xp-chip">
              <Icon name="bolt" size={16} />
              2.840 XP
            </div>
          </div>
        </div>
        {active === "home" && <Home go={go} />}
        {active === "study" && <Study />}
        {active === "quiz" && <Quiz />}
        {active === "exam" && <Exam />}
        {active === "streak" && <Streak />}
        {active === "more" && <More go={go} />}
        {["search", "weak", "board"].includes(active) && (
          <Placeholder id={active} go={go} />
        )}
      </main>
      <nav className="bottom-nav">
        {[
          nav[0],
          nav[1],
          nav[2],
          tools[0],
          { id: "more", label: "Mehr", icon: "more" as IconName },
        ].map((item) => (
          <button
            key={item.id}
            className={
              active === item.id ||
              (item.id === "more" &&
                ["search", "weak", "board"].includes(active))
                ? "active"
                : ""
            }
            onClick={() => go(item.id)}
          >
            <span>
              <Icon name={item.icon} />
              {item.id === "study" && <i>18</i>}
            </span>
            <small>{item.label}</small>
          </button>
        ))}
      </nav>
    </div>
  )
}
